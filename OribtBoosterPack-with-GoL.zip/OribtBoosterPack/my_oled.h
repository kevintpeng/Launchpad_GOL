#if !defined(MYOLED_INC)
#define	MYOLED_INC

void init_OLED();
void setup_OLED();
void init_LEDS();

#endif

